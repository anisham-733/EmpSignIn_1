﻿namespace EmployeeSignIn.Services
{
    public interface IService
    {
    }
}
