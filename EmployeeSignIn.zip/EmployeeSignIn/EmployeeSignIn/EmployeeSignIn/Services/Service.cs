﻿namespace EmployeeSignIn.Services
{
    public class Service:IService
    {
    }
}
