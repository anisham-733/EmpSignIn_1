﻿namespace EmployeeSignIn.Repositories
{
    public class IRepository
    {
    }
}
