﻿namespace EmployeeSignIn.Repositories
{
    public class Repository:IRepository
    {
    }
}
